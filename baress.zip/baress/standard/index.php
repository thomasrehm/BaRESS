<?php
$standard = TRUE;
include "_inc/header.php";
?>

<title>BaRESS – Standard Webseite</title>

</head>


<body>

<? include "_inc/nav.php";
include "_inc/carousel.php" ?>


<!-- Marketing messaging and featurettes
================================================== -->
<!-- Wrap the rest of the page in another container to center all the content. -->

<div class="container marketing">

    <? include "_inc/infocol.php"; ?>


    <? include "_inc/featurettes.php"; ?>


    <? // include "_inc/plugins.php" ?>




    <!-- /END THE FEATURETTES -->
    <hr class="featurette-divider">




    <? include "_inc/footer.php"; ?>
