<?php ?>

<!-- FOOTER -->
<footer>
<div class="col-md-12">
    <p class="pull-right"><a href="#">Back to top</a></p>
    <p>&copy; 2013 Thomas Rehm</p>
</div>
</footer>

</div><!-- /.container -->


</body>
</html>
