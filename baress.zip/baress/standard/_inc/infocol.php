<?php ?>

<!-- Three columns of text below the carousel -->
<div class="row">
    <div class="col-lg-4 col-lg-offset-4">
        <img src="svg/packman.svg" type="image/svg+xml" width="auto" height="200px">


        <h2 class="text-muted">Packman</h2>

        <p>Diese Seite hier ist die Standard-Version der BaRESS-Webseite.
        Hier ist noch nichts optimiert oder verbessert. Es sind keine Performance-Regeln eingehalten
        worden. Also lieber schnell weiter.</p>


        <a class="btn btn-lg btn-default" href="../optimiert/" role="button">» Zur optimierten Site</a>
    </div>
    <!-- /.col-lg-4 -->

</div><!-- /.row -->
