<?php
namespace ScientiaMobile\WurflCloud;
/**
 * This software is the Copyright of ScientiaMobile, Inc.
 * 
 * Please refer to the LICENSE.txt file distributed with the software for licensing information.
 * 
 * @package ScientiaMobile\WurflCloud
 */

class Exception extends \Exception {}
